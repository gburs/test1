﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Transform
{
    public partial class Main : Form
    {


        //-----------------------------------------------------
        // 
        // 
        //-----------------------------------------------------
        public Main()
        {
            InitializeComponent();
        }

        //-----------------------------------------------------
        // When exit button is clicked 
        // 
        //-----------------------------------------------------
        private void buttonExitApplication_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }


        //-----------------------------------------------------
        // Declaration of the structures holding the
        // file input and output definitions
        //-----------------------------------------------------
        public struct def_FileInputFormat
        {
            public Int64 ID;
            public string Format;
            public bool hasHeader;

            //constructor
            public def_FileInputFormat(Int64 p_ID, string p_Format, bool p_hasHeader)
            {
                ID = p_ID;
                Format = p_Format;
                hasHeader = p_hasHeader;
            }
        }

        public struct def_FileInputFormat_Fields
        {
            public Int64 ID;
            public Int64 ID_def_FileInputFormat;
            public int Field_No;
            public string Field_Name;
            public string Field_Type;
            public int Field_Length;
            public bool Field_isMandatory;
            public string Field_Format;
            public string Field_OutputReplacementFormat;

            //constructor
            public def_FileInputFormat_Fields(
                Int64 p_ID,
                Int64 p_ID_def_FileInputFormat,
                int p_Field_No,
                string p_Field_Name,
                string p_Field_Type,
                int p_Field_Length,
                bool p_Field_isMandatory,
                string p_Field_Format,
                string p_Field_OutputReplacementFormat
                )
            {
                ID = p_ID;
                ID_def_FileInputFormat = p_ID_def_FileInputFormat;
                Field_No = p_Field_No;
                Field_Name = p_Field_Name;
                Field_Type = p_Field_Type;
                Field_Length = p_Field_Length;
                Field_isMandatory = p_Field_isMandatory;
                Field_Format = p_Field_Format;
                Field_OutputReplacementFormat = p_Field_OutputReplacementFormat;
            }
        }

        public struct def_FileInputFormat_Fields_AcceptedValues
        {
            public Int64 ID;
            public Int64 ID_def_FileInputFormat_Fields;
            public string Value;
            public string OutputReplacementValue;

            //constructor
            public def_FileInputFormat_Fields_AcceptedValues(
                Int64 p_ID,
                Int64 p_ID_def_FileInputFormat_Fields,
                string p_Value,
                string p_OutputReplacementValue
                )
            {
                ID = p_ID;
                ID_def_FileInputFormat_Fields = p_ID_def_FileInputFormat_Fields;
                Value = p_Value;
                OutputReplacementValue = p_OutputReplacementValue;
            }
        }

        public struct def_FileOutputFormat_Fields
        {
            public Int64 ID;
            public Int64 ID_def_FileInputFormat;
            public int Field_No;
            public string Field_Name;
            public string Field_Type;
            public int Field_Length;
            public bool Field_isMandatory;
            public string Field_Format;

            //constructor
            public def_FileOutputFormat_Fields(
                Int64 p_ID,
                Int64 p_ID_def_FileInputFormat,
                int p_Field_No,
                string p_Field_Name,
                string p_Field_Type,
                int p_Field_Length,
                bool p_Field_isMandatory,
                string p_Field_Format
                )
            {
                ID = p_ID;
                ID_def_FileInputFormat = p_ID_def_FileInputFormat;
                Field_No = p_Field_No;
                Field_Name = p_Field_Name;
                Field_Type = p_Field_Type;
                Field_Length = p_Field_Length;
                Field_isMandatory = p_Field_isMandatory;
                Field_Format = p_Field_Format;
            }
        }

        public struct def_Mapping_FileInput_FileOutput
        {
            public Int64 ID_FileInputFormat;
            public int FieldNo_FileInput;
            public int FieldNo_FileOutput;

            //constructor
            public def_Mapping_FileInput_FileOutput(
                Int64 p_ID_FileInputFormat,
                int p_FieldNo_FileInput,
                int p_FieldNo_FileOutput
                )
            {
                ID_FileInputFormat = p_ID_FileInputFormat;
                FieldNo_FileInput = p_FieldNo_FileInput;
                FieldNo_FileOutput = p_FieldNo_FileOutput;
            }
        };

        //-----------------------------------------------------
        // END
        // Declaration of the structures holding the
        // file input and output definitions
        //-----------------------------------------------------




        //-----------------------------------------------------
        // define the arrays for 
        // Input & Output Formats and initialize the values
        //-----------------------------------------------------

        //input formats
        public def_FileInputFormat[] FileInputFormat = new def_FileInputFormat[]
        {
            new def_FileInputFormat(1, "Format1",true),
            new def_FileInputFormat(2, "Format2",false)
        };

        //fields or columns of each format 
        public def_FileInputFormat_Fields[] FileInputFormat_Fields = new def_FileInputFormat_Fields[]
        {
            new def_FileInputFormat_Fields(1,1,0,"Identifier","varchar",100,true,"","Special:VBAR_DIV_NOtoACCCODE"),
            new def_FileInputFormat_Fields(2,1,1,"Name","varchar",100,true,"",""),
            new def_FileInputFormat_Fields(3,1,2,"Type","varchar",1,true,"",""),
            new def_FileInputFormat_Fields(4,1,3,"Opened","date",10,false,"MM-dd-yyyy","yyyy-MM-dd"),
            new def_FileInputFormat_Fields(5,1,4,"Currency","varchar",2,true,"",""),
            new def_FileInputFormat_Fields(6,2,0,"Name","varchar",100,true,"",""),
            new def_FileInputFormat_Fields(7,2,1,"Type","varchar",10,true,"",""),
            new def_FileInputFormat_Fields(8,2,2,"Currency","varchar",1,true,"",""),
            new def_FileInputFormat_Fields(9,2,3,"Custodian Code","varchar",100,true,"","")
        };

        //accepted values (with replacement) for each field of each format
        //if a field is not found, there is no value restriction
        public def_FileInputFormat_Fields_AcceptedValues[] FileInputFormat_Fields_AcceptedValues = new def_FileInputFormat_Fields_AcceptedValues[]
        {
            new def_FileInputFormat_Fields_AcceptedValues(1,3,"1","Trading"),
            new def_FileInputFormat_Fields_AcceptedValues(2,3,"2","RRSP"),
            new def_FileInputFormat_Fields_AcceptedValues(3,3,"3","RESP"),
            new def_FileInputFormat_Fields_AcceptedValues(4,3,"4","Fund"),
            new def_FileInputFormat_Fields_AcceptedValues(5,5,"CD","CAD"),
            new def_FileInputFormat_Fields_AcceptedValues(6,5,"US","USD"),
            new def_FileInputFormat_Fields_AcceptedValues(7,8,"C","CAD"),
            new def_FileInputFormat_Fields_AcceptedValues(9,8,"U","USD"),
            new def_FileInputFormat_Fields_AcceptedValues(10,7,"Trading",""),
            new def_FileInputFormat_Fields_AcceptedValues(11,7,"RRSP",""),
            new def_FileInputFormat_Fields_AcceptedValues(12,7,"RESP",""),
            new def_FileInputFormat_Fields_AcceptedValues(13,7,"Fund","")
        };

        //target output format
        public def_FileOutputFormat_Fields[] FileOutputFormat_Fields = new def_FileOutputFormat_Fields[]
        {
            new def_FileOutputFormat_Fields(1,1,0,"AccountCode","varchar",100,true,""),
            new def_FileOutputFormat_Fields(2,1,1,"Name","varchar",100,true,""),
            new def_FileOutputFormat_Fields(3,1,2,"Type","varchar",10,true,""),
            new def_FileOutputFormat_Fields(4,1,3,"Open Date","date",10,false,"yyyy-MM-dd"),
            new def_FileOutputFormat_Fields(5,1,4,"Currency","varchar",3,true,""),
        };

        //maapping of input fields to output, it is the cross order of CSV columns
        //Note: for the mapping to work properly the second field "FieldNo_FileInput" has to be in chronological order when added to array
        public def_Mapping_FileInput_FileOutput[] Mapping_FileInput_FileOutput = new def_Mapping_FileInput_FileOutput[]
        {
            new def_Mapping_FileInput_FileOutput(1,0,0),
            new def_Mapping_FileInput_FileOutput(1,1,1),
            new def_Mapping_FileInput_FileOutput(1,2,2),
            new def_Mapping_FileInput_FileOutput(1,3,3),
            new def_Mapping_FileInput_FileOutput(1,4,4),
            new def_Mapping_FileInput_FileOutput(2,0,1),
            new def_Mapping_FileInput_FileOutput(2,1,2),
            new def_Mapping_FileInput_FileOutput(2,2,4),
            new def_Mapping_FileInput_FileOutput(2,3,0),
        };

        //-----------------------------------------------------
        // END
        // define the arrays for 
        // Input & Output Format and initialize the values
        //-----------------------------------------------------



        //-----------------------------------------------------
        // From DB gets the input formats 
        // and displays them into the DropDown ReadOnly
        //-----------------------------------------------------
        private void GetInputFromats()
        {
            comboBoxInputFormat.Items.Clear();

            //bind the combobox to a dictionary as the record ID in the table is needed - is the Key in the List
            Dictionary<string, string> comboSource = new Dictionary<string, string>();

            for (int i = 0; i < FileInputFormat.Length; i++)
            {
                comboSource.Add(FileInputFormat[i].ID.ToString(), FileInputFormat[i].Format.ToString());
            }

            comboBoxInputFormat.DataSource = new BindingSource(comboSource, null);
            comboBoxInputFormat.DisplayMember = "Value";
            comboBoxInputFormat.ValueMember = "Key";

            //for retrieval use
            //string key = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Key;
            //string value = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Value;

        }


        //-----------------------------------------------------
        // When the main form loads  
        // it initializes the popup Formats
        //-----------------------------------------------------
        private void Main_Load(object sender, EventArgs e)
        {
            //load the input formats into the DropDown
            GetInputFromats();

        }

        //-----------------------------------------------------
        // Clear the output box after format is changed 
        // 
        //-----------------------------------------------------
        private void comboBoxInputFormat_SelectedIndexChanged(object sender, EventArgs e)
        {
            //clear the output result display
            textBoxOutputDetails.Text = "";

        }

        //-----------------------------------------------------
        // Called when the Select Input File Button is 
        // clicked to force the FileOpen dialog to show
        //-----------------------------------------------------
        private void buttonSelectInputFile_Click(object sender, EventArgs e)
        {
            openFileInputDialog1.FileName = "";
            openFileInputDialog1.ShowDialog();
        }

        //-----------------------------------------------------
        // Called when the Ok is pressed 
        // on the file input selection
        //-----------------------------------------------------
        private void openFileInputDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (openFileInputDialog1.FileName != "")
            {
                textBoxInputFileName.Text = openFileInputDialog1.FileName;

                //clear the output result display
                textBoxOutputDetails.Text = "";
            }

        }

        //-----------------------------------------------------
        // Generates the output file when
        // button Generate Output File is called
        // 
        // Logic of the file output generation is here
        // and is based on the structure definition
        // 
        // It is dynamic and fits inputs generating this 
        // target output or extended targeted output of
        // up to 10 columns in the CSV file 
        //
        //-----------------------------------------------------
        private void buttonGenerateOutputFile_Click(object sender, EventArgs e)
        {
            //show a dialog box with Ok/Cancel buttons
            MessageBoxButtons db_buttons = MessageBoxButtons.OKCancel;
            DialogResult db_result;

            //display the dialog box and go on if fine
            db_result = MessageBox.Show("Confirm proceeding with file output generation?", "Confirmation", db_buttons);

            //proceed on confirmation only
            if (db_result == System.Windows.Forms.DialogResult.OK)
            {
                bool bProceed = true;

                //clear the output result display
                textBoxOutputDetails.Text = "";

                //check file format existance
                if (bProceed)
                {
                    if (comboBoxInputFormat.SelectedIndex == -1)
                    {
                        db_buttons = MessageBoxButtons.OK;
                        MessageBox.Show("Sorry... No Input Format Selected? \n(Select a format from the DropDown)", "Error", db_buttons);
                        bProceed = false;
                    }

                }

                //check file name existance
                if (bProceed)
                {
                    if (textBoxInputFileName.Text == "")
                    {
                        db_buttons = MessageBoxButtons.OK;
                        MessageBox.Show("Sorry... No Input File Selected? \n(Press Select Input File)", "Error", db_buttons);
                        bProceed = false;
                    }
                }

                //Step 1 Import File into the Raw Table
                if (bProceed)
                {
                    //set cursor to hourglass
                    Cursor.Current = Cursors.WaitCursor;
                    Application.UseWaitCursor = true;

                    //get the file format ID for validating the format definition
                    string sFileFormatID = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Key;                     

                    //set the user notification based on user_notification flags
                    bool user_notification_has_rejects = false;
                    bool user_notification_has_out_records = false;


                    //read the file line by line and process it
                    try
                    {

                        //set Errors File: 
                        StreamWriter sw_ERR = new StreamWriter(textBoxInputFileName.Text + ".err");

                        //set TEMP File: (in tmp file the output values are fine, however, the fields order is not fine, the mapping fixes that)
                        StreamWriter sw_TEMP = new StreamWriter(textBoxInputFileName.Text + ".tmp");

                        Int64 iCountLong = 1;

                        using (StreamReader sr = new StreamReader(textBoxInputFileName.Text))
                        {

                            //each line is comma split to obtain the fields 
                            while (!sr.EndOfStream)
                            {

                                //zero based in Field_No in the def_FileInputFormat_Fields table for allignement
                                string[] sFields = sr.ReadLine().Split(',');

                                //field values, now 10 and is the maximum number of fields from all imports
                                string sField_0 = "";
                                string sField_1 = "";
                                string sField_2 = "";
                                string sField_3 = "";
                                string sField_4 = "";
                                string sField_5 = "";
                                string sField_6 = "";
                                string sField_7 = "";
                                string sField_8 = "";
                                string sField_9 = "";


                                //skip the header if encountered
                                if (!(
                                            (iCountLong == 1)
                                            &&
                                            (FileInputFormat[Convert.ToInt32(sFileFormatID) - 1].hasHeader) 
                                        )
                                   )
                                {

                                    //validate each field against the definition, if error display it
                                    for (int i = 0; i < sFields.Length; i++)
                                    {
                                        //scan the structure for the appropriate FormatID and Field_No
                                        for (int j = 0; j < FileInputFormat_Fields.Length; j++)
                                        {
                                            if (
                                                    (FileInputFormat_Fields[j].ID_def_FileInputFormat.ToString() == sFileFormatID)
                                                     &&
                                                    (FileInputFormat_Fields[j].Field_No == i)
                                               )
                                            {
                                                switch (FileInputFormat_Fields[j].Field_Type)
                                                {
                                                    case "varchar":
                                                        {
                                                            //special parsing allways at the top
                                                            //check special cases and each has to be implemented separately
                                                            if (FileInputFormat_Fields[j].Field_OutputReplacementFormat != "")
                                                            {
                                                                switch (FileInputFormat_Fields[j].Field_OutputReplacementFormat)
                                                                {
                                                                    case "Special:VBAR_DIV_NOtoACCCODE":
                                                                        string[] sSpecial = sFields[i].Split('|');

                                                                        //check if condition is met
                                                                        if (sSpecial.Length == 2)
                                                                        {
                                                                            sFields[i] = sSpecial[1];
                                                                        }
                                                                        else //there is an error, special character not found
                                                                        {
                                                                            sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " does not have the special vertical bar character: |.");
                                                                            user_notification_has_rejects = true;
                                                                        }

                                                                        break;

                                                                }
                                                            }

                                                            //check length
                                                            if (sFields[i].Length > FileInputFormat_Fields[j].Field_Length)
                                                            {
                                                                sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " has the length in excess of the definition. ");
                                                                user_notification_has_rejects = true;
                                                            }

                                                            //check mandatory (takes care of the special case too)
                                                            if (
                                                                  (sFields[i].Trim().Length == 0)
                                                                  &&
                                                                  (FileInputFormat_Fields[j].Field_isMandatory)
                                                               )
                                                            {
                                                                if (FileInputFormat_Fields[j].Field_OutputReplacementFormat == "")
                                                                {//no special transformation case
                                                                    sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " is mandatory. ");
                                                                    user_notification_has_rejects = true;
                                                                }
                                                                else
                                                                {//add the special description (!!! make sure it is meaningful to the user)
                                                                    sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " is mandatory - " + FileInputFormat_Fields[j].Field_OutputReplacementFormat);
                                                                    user_notification_has_rejects = true;
                                                                }

                                                            }

                                                            //check if in accepted range

                                                            //variable to check if value found; 
                                                            //counter based, works as follows:
                                                            //if the counter is 0 then any value is acceptable
                                                            //if the counter is > 0 then at least one value has to match, otherwise error 
                                                            int counter_FieldValueConstraint = 0;
                                                            bool found_FieldValueConstraint = false;

                                                            //scan the accepted values for this field ID
                                                            for (int i_0 = 0; i_0 < FileInputFormat_Fields_AcceptedValues.Length; i_0++)
                                                            {
                                                                if (FileInputFormat_Fields_AcceptedValues[i_0].ID_def_FileInputFormat_Fields == FileInputFormat_Fields[j].ID)
                                                                {
                                                                    counter_FieldValueConstraint++;
                                                                    if (sFields[i] == FileInputFormat_Fields_AcceptedValues[i_0].Value)
                                                                    {
                                                                        //check for replacement value
                                                                        if (FileInputFormat_Fields_AcceptedValues[i_0].OutputReplacementValue != "")
                                                                        {
                                                                            sFields[i] = FileInputFormat_Fields_AcceptedValues[i_0].OutputReplacementValue;
                                                                        }

                                                                        //mark it found to avoid generating error messages
                                                                        found_FieldValueConstraint = true;

                                                                        //no point in going further
                                                                        break;
                                                                    }

                                                                }
                                                            }

                                                            //add to reject if not found
                                                            if (
                                                                (counter_FieldValueConstraint > 0)
                                                                &&
                                                                (!found_FieldValueConstraint)
                                                              )
                                                            {
                                                                sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " value is not found in the accepted values list.");
                                                                user_notification_has_rejects = true;
                                                            }

                                                            break;
                                                        }
                                                    case "date":
                                                        {
                                                            //check mandatory
                                                            if (
                                                                  (sFields[i].Trim().Length == 0)
                                                                  &&
                                                                  (FileInputFormat_Fields[j].Field_isMandatory)
                                                               )
                                                            {
                                                                sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " is mandatory. ");
                                                                user_notification_has_rejects = true;
                                                            }

                                                            //check format
                                                            if (
                                                                  (sFields[i].Length > 0)
                                                                  &&
                                                                  (FileInputFormat_Fields[j].Field_Format.Length > 0)
                                                               )
                                                            {
                                                                try
                                                                {
                                                                    DateTime dTempDateTime = DateTime.ParseExact(sFields[i], FileInputFormat_Fields[j].Field_Format, null);

                                                                    //if all good replace the field with the output conersion format
                                                                    sFields[i] = dTempDateTime.ToString(FileInputFormat_Fields[i].Field_OutputReplacementFormat);

                                                                }
                                                                catch
                                                                {
                                                                    sw_ERR.WriteLine("Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + FileInputFormat_Fields[j].Field_Name + " has a date format issue. ");
                                                                    user_notification_has_rejects = true;
                                                                }
                                                            }

                                                            break;
                                                        }
                                                }
                                            }
                                        }

                                        
                                        //translate the table into fields
                                        //!!! Attention to mapping, it is one-to-one
                                        switch (i)
                                        {
                                            case 0: sField_0 = sFields[i]; break;
                                            case 1: sField_1 = sFields[i]; break;
                                            case 2: sField_2 = sFields[i]; break;
                                            case 3: sField_3 = sFields[i]; break;
                                            case 4: sField_4 = sFields[i]; break;
                                            case 5: sField_5 = sFields[i]; break;
                                            case 6: sField_6 = sFields[i]; break;
                                            case 7: sField_7 = sFields[i]; break;
                                            case 8: sField_8 = sFields[i]; break;
                                            case 9: sField_9 = sFields[i]; break;
                                        }

                                    }

                                    //here the line should have all the fields fine including their replacement value
                                    //nonetheless, fields may not be in the correct order, mapping fixes this
                                    //write it to the TEMP file
                                    sw_TEMP.WriteLine(sField_0 + "," + sField_1 + "," + sField_2 + "," + sField_3 + "," + sField_4 + "," + sField_5 + "," + sField_6 + "," + sField_7 + "," + sField_8 + "," + sField_9);
                                    user_notification_has_out_records = true;

                                }

                                iCountLong++;
                            }
                        }

                        //close Error File handler
                        sw_ERR.Flush();
                        sw_ERR.Close();
                        sw_ERR.Dispose();

                        //close TEMP File handler
                        sw_TEMP.Flush();
                        sw_TEMP.Close();
                        sw_TEMP.Dispose();

                    }
                    catch (Exception ex)
                    {
                        textBoxOutputDetails.AppendText("Sorry... This file could not be processed - does not exist or could not be read or temp files could not be created!");
                        textBoxOutputDetails.AppendText(Environment.NewLine);
                        if (ex.Message != "")
                        {
                            textBoxOutputDetails.AppendText(ex.Message);
                            textBoxOutputDetails.AppendText(Environment.NewLine);
                        }

                        //file could not be found or read, system error, no point in going any further
                        bProceed = false;

                    }


                    //Step 2: 
                    //  2.a - set user notification
                    //  2.b - follows the mapping for generating the out file
                    if (bProceed)
                    {
                        //set user notification based on flags
                        if (user_notification_has_rejects)
                        {
                            textBoxOutputDetails.AppendText("Rejects found, details in file: " + textBoxInputFileName.Text + ".err");
                            textBoxOutputDetails.AppendText(Environment.NewLine);

                            //dete the out
                            try
                            {
                                File.Delete(textBoxInputFileName.Text + ".out");
                            }
                            catch
                            {
                            }
                        }
                        else//no rejects, fix the mapping if there are any records
                        {
                            //dete the err
                            try
                            {
                                File.Delete(textBoxInputFileName.Text + ".err");
                            }
                            catch
                            {
                            }

                            if (user_notification_has_out_records)
                            {


                                //have it wrapped within a [try catch] to capture any errors
                                try
                                {
                                    //set OUT File
                                    StreamWriter sw_OUT = new StreamWriter(textBoxInputFileName.Text + ".out");

                                    //write the header 
                                    string sOUT_Header = "";
                                    if (FileOutputFormat_Fields.Length > 0)
                                    {
                                        for (int i = 0; i < FileOutputFormat_Fields.Length; i++)
                                        {
                                            sOUT_Header = sOUT_Header + FileOutputFormat_Fields[i].Field_Name + ",";
                                        }

                                        sw_OUT.WriteLine(sOUT_Header.Substring(0, sOUT_Header.Length - 1));
                                    }

                                    
                                    //get the mappings of fileds, input to output
                                    //so far, set 10 Fields
                                    int[] table_Mapping_Input_TO_Ouptut = new int[] {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};

                                    int iCounter=0;

                                    for (int i=0;i<Mapping_FileInput_FileOutput.Length; i++)
                                    {
                                        if (Mapping_FileInput_FileOutput[i].ID_FileInputFormat.ToString() == sFileFormatID)
                                        {
                                            table_Mapping_Input_TO_Ouptut[iCounter] = Mapping_FileInput_FileOutput[i].FieldNo_FileOutput;
                                            iCounter++;
                                        }
                                    }


                                    //END get the mappings of fileds, input to output


                                    using (StreamReader sr_TEMP = new StreamReader(textBoxInputFileName.Text + ".tmp"))
                                    {
                                        //each line is comma split to obtain the fields 
                                        while (!sr_TEMP.EndOfStream)
                                        {

                                            //zero based in Field_No in the def_FileInputFormat_Fields table for allignement
                                            string[] sFields = sr_TEMP.ReadLine().Split(',');

                                            //field values, now 10 and is the maximum number of fields from all imports
                                            string sField_0_OUT = "";
                                            string sField_1_OUT = "";
                                            string sField_2_OUT = "";
                                            string sField_3_OUT = "";
                                            string sField_4_OUT = "";
                                            string sField_5_OUT = "";
                                            string sField_6_OUT = "";
                                            string sField_7_OUT = "";
                                            string sField_8_OUT = "";
                                            string sField_9_OUT = "";

                                            //re-arrange the fields based on the mapping
                                            for (int j = 0; j < sFields.Length; j++)
                                            {
                                                switch (table_Mapping_Input_TO_Ouptut[j])
                                                {
                                                    case 0: sField_0_OUT = sFields[j]; break;
                                                    case 1: sField_1_OUT = sFields[j]; break;
                                                    case 2: sField_2_OUT = sFields[j]; break;
                                                    case 3: sField_3_OUT = sFields[j]; break;
                                                    case 4: sField_4_OUT = sFields[j]; break;
                                                    case 5: sField_5_OUT = sFields[j]; break;
                                                    case 6: sField_6_OUT = sFields[j]; break;
                                                    case 7: sField_7_OUT = sFields[j]; break;
                                                    case 8: sField_8_OUT = sFields[j]; break;
                                                    case 9: sField_9_OUT = sFields[j]; break;
                                                }
                                            }

                                            //write to the out based on the length of the output table
                                            switch (FileOutputFormat_Fields.Length)
                                            {
                                                case 1: sw_OUT.WriteLine(sField_0_OUT); break;
                                                case 2: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT); break;
                                                case 3: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT); break;
                                                case 4: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT); break;
                                                case 5: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT); break;
                                                case 6: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT + "," + sField_5_OUT); break;
                                                case 7: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT + "," + sField_5_OUT + "," + sField_6_OUT); break;
                                                case 8: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT + "," + sField_5_OUT + "," + sField_6_OUT + "," + sField_7_OUT); break;
                                                case 9: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT + "," + sField_5_OUT + "," + sField_6_OUT + "," + sField_7_OUT + "," + sField_8_OUT); break;
                                                case 10: sw_OUT.WriteLine(sField_0_OUT + "," + sField_1_OUT + "," + sField_2_OUT + "," + sField_3_OUT + "," + sField_4_OUT + "," + sField_5_OUT + "," + sField_6_OUT + "," + sField_7_OUT + "," + sField_8_OUT + "," + sField_9_OUT); break;
                                            }

                                        }

                                        //signalize the user
                                        textBoxOutputDetails.AppendText("Output generated in file: " + textBoxInputFileName.Text + ".out");
                                        textBoxOutputDetails.AppendText(Environment.NewLine);

                                    }

                                    //close OUT File handler
                                    sw_OUT.Flush();
                                    sw_OUT.Close();
                                    sw_OUT.Dispose();


                                }
                                catch (Exception ex)
                                {
                                    textBoxOutputDetails.AppendText("Sorry... Records could not be written to the output file!");
                                    textBoxOutputDetails.AppendText(Environment.NewLine);

                                    if (ex.Message != "")
                                    {
                                        textBoxOutputDetails.AppendText(ex.Message);
                                        textBoxOutputDetails.AppendText(Environment.NewLine);
                                    }
                                }


                            }

                        }
                    }


                    //clear the TEMP file 
                    try
                    {
                        File.Delete(textBoxInputFileName.Text + ".tmp");
                    }
                    catch
                    {
                    }


                    //reset the cursor back
                    Cursor.Current = Cursors.Default;
                    Application.UseWaitCursor = false;
                }

            }



        }

    }
}
