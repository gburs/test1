USE [master]
GO

/******!!! Attention: A user is created with sysadmin role ******/

CREATE LOGIN [User2] WITH PASSWORD=N'User2', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

EXEC sys.sp_addsrvrolemember @loginame = N'User2', @rolename = N'sysadmin'
GO




/****** Object:  Database [ToogoodMaster2]    Script Date: 05/25/2019 12:18:57 ******/
CREATE DATABASE [ToogoodMaster2] ON  PRIMARY 
( NAME = N'ToogoodMaster2', FILENAME = N'C:\TESTS\Toogood\ToogoodMaster2.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'ToogoodMaster2_log', FILENAME = N'C:\TESTS\Toogood\ToogoodMaster2_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [ToogoodMaster2] SET COMPATIBILITY_LEVEL = 100
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [ToogoodMaster2].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [ToogoodMaster2] SET ANSI_NULL_DEFAULT OFF
GO
ALTER DATABASE [ToogoodMaster2] SET ANSI_NULLS OFF
GO
ALTER DATABASE [ToogoodMaster2] SET ANSI_PADDING OFF
GO
ALTER DATABASE [ToogoodMaster2] SET ANSI_WARNINGS OFF
GO
ALTER DATABASE [ToogoodMaster2] SET ARITHABORT OFF
GO
ALTER DATABASE [ToogoodMaster2] SET AUTO_CLOSE OFF
GO
ALTER DATABASE [ToogoodMaster2] SET AUTO_CREATE_STATISTICS ON
GO
ALTER DATABASE [ToogoodMaster2] SET AUTO_SHRINK OFF
GO
ALTER DATABASE [ToogoodMaster2] SET AUTO_UPDATE_STATISTICS ON
GO
ALTER DATABASE [ToogoodMaster2] SET CURSOR_CLOSE_ON_COMMIT OFF
GO
ALTER DATABASE [ToogoodMaster2] SET CURSOR_DEFAULT  GLOBAL
GO
ALTER DATABASE [ToogoodMaster2] SET CONCAT_NULL_YIELDS_NULL OFF
GO
ALTER DATABASE [ToogoodMaster2] SET NUMERIC_ROUNDABORT OFF
GO
ALTER DATABASE [ToogoodMaster2] SET QUOTED_IDENTIFIER OFF
GO
ALTER DATABASE [ToogoodMaster2] SET RECURSIVE_TRIGGERS OFF
GO
ALTER DATABASE [ToogoodMaster2] SET  DISABLE_BROKER
GO
ALTER DATABASE [ToogoodMaster2] SET AUTO_UPDATE_STATISTICS_ASYNC OFF
GO
ALTER DATABASE [ToogoodMaster2] SET DATE_CORRELATION_OPTIMIZATION OFF
GO
ALTER DATABASE [ToogoodMaster2] SET TRUSTWORTHY OFF
GO
ALTER DATABASE [ToogoodMaster2] SET ALLOW_SNAPSHOT_ISOLATION OFF
GO
ALTER DATABASE [ToogoodMaster2] SET PARAMETERIZATION SIMPLE
GO
ALTER DATABASE [ToogoodMaster2] SET READ_COMMITTED_SNAPSHOT OFF
GO
ALTER DATABASE [ToogoodMaster2] SET HONOR_BROKER_PRIORITY OFF
GO
ALTER DATABASE [ToogoodMaster2] SET  READ_WRITE
GO
ALTER DATABASE [ToogoodMaster2] SET RECOVERY FULL
GO
ALTER DATABASE [ToogoodMaster2] SET  MULTI_USER
GO
ALTER DATABASE [ToogoodMaster2] SET PAGE_VERIFY CHECKSUM
GO
ALTER DATABASE [ToogoodMaster2] SET DB_CHAINING OFF
GO
USE [ToogoodMaster2]
GO
/****** Object:  Table [dbo].[raw_FileOutput]    Script Date: 05/25/2019 12:18:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[raw_FileOutput](
	[ID] [bigint] NOT NULL,
	[Field_0] [varchar](255) NULL,
	[Field_1] [varchar](255) NULL,
	[Field_2] [varchar](255) NULL,
	[Field_3] [varchar](255) NULL,
	[Field_4] [varchar](255) NULL,
	[Field_5] [varchar](255) NULL,
	[Field_6] [varchar](255) NULL,
	[Field_7] [varchar](255) NULL,
	[Field_8] [varchar](255) NULL,
	[Field_9] [varchar](255) NULL,
 CONSTRAINT [PK_raw_FileOutput] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[raw_FileInput_Rejects]    Script Date: 05/25/2019 12:18:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[raw_FileInput_Rejects](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Notes] [varchar](255) NULL,
 CONSTRAINT [PK_raw_FileInput_Rejects] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[raw_FileInput_Rejects] ON
INSERT [dbo].[raw_FileInput_Rejects] ([ID], [Notes]) VALUES (1, N'Row#: 2 - Field: Identifier does not have the special vertical bar character: |.')
INSERT [dbo].[raw_FileInput_Rejects] ([ID], [Notes]) VALUES (2, N'Row#: 2 - Field: Opened has a date format issue. ')
SET IDENTITY_INSERT [dbo].[raw_FileInput_Rejects] OFF
/****** Object:  Table [dbo].[raw_FileInput]    Script Date: 05/25/2019 12:18:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[raw_FileInput](
	[ID] [bigint] NOT NULL,
	[Field_NULL] [varchar](255) NULL,
	[Field_0] [varchar](255) NULL,
	[Field_1] [varchar](255) NULL,
	[Field_2] [varchar](255) NULL,
	[Field_3] [varchar](255) NULL,
	[Field_4] [varchar](255) NULL,
	[Field_5] [varchar](255) NULL,
	[Field_6] [varchar](255) NULL,
	[Field_7] [varchar](255) NULL,
	[Field_8] [varchar](255) NULL,
	[Field_9] [varchar](255) NULL,
 CONSTRAINT [PK_raw_FileInput] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
INSERT [dbo].[raw_FileInput] ([ID], [Field_NULL], [Field_0], [Field_1], [Field_2], [Field_3], [Field_4], [Field_5], [Field_6], [Field_7], [Field_8], [Field_9]) VALUES (2, NULL, N'My Account2', N'RRSP', N'U', N'AbcCode3', N'', N'', N'', N'', N'', N'')
/****** Object:  Table [dbo].[def_FileInputFormat]    Script Date: 05/25/2019 12:18:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[def_FileInputFormat](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Format] [varchar](50) NOT NULL,
	[hasHeader] [bit] NOT NULL,
 CONSTRAINT [PK_def_FileInputFormat] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_def_FileInputFormat_Field_Format_Unique] ON [dbo].[def_FileInputFormat] 
(
	[Format] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[def_FileInputFormat] ON
INSERT [dbo].[def_FileInputFormat] ([ID], [Format], [hasHeader]) VALUES (1, N'Format 1', 1)
INSERT [dbo].[def_FileInputFormat] ([ID], [Format], [hasHeader]) VALUES (2, N'Format 2', 0)
SET IDENTITY_INSERT [dbo].[def_FileInputFormat] OFF
/****** Object:  Table [dbo].[def_FileOutputFormat_Fields]    Script Date: 05/25/2019 12:18:58 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[def_FileOutputFormat_Fields](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Field_No] [int] NOT NULL,
	[Field_Name] [varchar](50) NOT NULL,
	[Field_Type] [varchar](50) NOT NULL,
	[Field_Length] [int] NOT NULL,
	[Field_isMandatory] [bit] NOT NULL,
	[Field_Format] [varchar](50) NULL,
 CONSTRAINT [PK_def_FileOutputFormat_Fields] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[def_FileOutputFormat_Fields] ON
INSERT [dbo].[def_FileOutputFormat_Fields] ([ID], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format]) VALUES (1, 0, N'AccountCode', N'varchar', 100, 1, NULL)
INSERT [dbo].[def_FileOutputFormat_Fields] ([ID], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format]) VALUES (2, 1, N'Name', N'varchar', 100, 1, NULL)
INSERT [dbo].[def_FileOutputFormat_Fields] ([ID], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format]) VALUES (3, 2, N'Type', N'varchar', 10, 1, NULL)
INSERT [dbo].[def_FileOutputFormat_Fields] ([ID], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format]) VALUES (4, 3, N'Open Date', N'date', 10, 0, N'yyyy-MM-dd')
INSERT [dbo].[def_FileOutputFormat_Fields] ([ID], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format]) VALUES (5, 4, N'Currency', N'varchar', 3, 1, NULL)
SET IDENTITY_INSERT [dbo].[def_FileOutputFormat_Fields] OFF
/****** Object:  StoredProcedure [dbo].[up_raw_Select_Rejects]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Select_Rejects]
 @par_sessionID varchar(50)
AS --
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    select 
           [ID]
          ,[Notes]
    from raw_FileInput_Rejects
    order by [ID]
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_raw_Select_Output_Data]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Select_Output_Data]
 @par_sessionID varchar(50)
AS --
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    select 
       [ID]
      ,[Field_0]
      ,[Field_1]
      ,[Field_2]
      ,[Field_3]
      ,[Field_4]
      ,[Field_5]
      ,[Field_6]
      ,[Field_7]
      ,[Field_8]
      ,[Field_9]
    from raw_FileOutput
    order by [ID]
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_def_Select_FileInputFormats]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_def_Select_FileInputFormats]
 @par_sessionID varchar(50)
AS --
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    select 
           [M].[ID]
          ,[M].[Format]
          ,[M].[hasHeader]
          --,isnull( (select count(sub_1.[ID]) from def_FileInputFormat_Fields sub_1 where sub_1.[ID_def_FileInputFormat] = [M].[ID]  ),0) as 'TotalNumberOfFields'
    from def_FileInputFormat [M]
    order by [ID]
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_raw_Do_Clear_All_RAW]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Do_Clear_All_RAW]
 @par_sessionID varchar(50),
 @par_result varchar(150) output
AS --
BEGIN
declare @_transaction_error int;  


-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION

    --1 raw Input
    delete
    from raw_FileInput

    --check status trasaction  
    select @_transaction_error = @@error
    if @_transaction_error <> 0 goto TRANSACTION_ERROR
    
    --1 raw Output
    delete
    from raw_FileOutput

    --check status trasaction  
    select @_transaction_error = @@error
    if @_transaction_error <> 0 goto TRANSACTION_ERROR
    

    --3 Rejects
    --recreation is recommended for resetting the identity 
    
	DROP TABLE [raw_FileInput_Rejects]

	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON

	CREATE TABLE [raw_FileInput_Rejects](
		[ID] [bigint] IDENTITY(1,1) NOT NULL,
		[Notes] [varchar](255) NULL,
	 CONSTRAINT [PK_raw_FileInput_Rejects] PRIMARY KEY CLUSTERED 
	(
		[ID] ASC
	) ON [PRIMARY]
	) ON [PRIMARY]

    --check status trasaction  
    select @_transaction_error = @@error
    if @_transaction_error <> 0 goto TRANSACTION_ERROR

	SET ANSI_PADDING OFF

    	   
COMMIT TRANSACTION
return 0
	   
TRANSACTION_ERROR:
IF @@TRANCOUNT > 0 
    BEGIN
      ROLLBACK TRANSACTION
      set @par_result = 'Database Error!';
    END
return @_transaction_error
    
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_raw_Do_Add_Reject]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Do_Add_Reject]
 @par_sessionID varchar(50),
 @par_notes varchar(255),
 @par_result varchar(150) output
AS --
BEGIN
declare @_transaction_error int;  


-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION


	insert into [raw_FileInput_Rejects]
	([Notes])
	values
	(@par_notes)

    --check status trasaction  
    select @_transaction_error = @@error
    if @_transaction_error <> 0 goto TRANSACTION_ERROR

    	   
COMMIT TRANSACTION
return 0
	   
TRANSACTION_ERROR:
IF @@TRANCOUNT > 0 
    BEGIN
      ROLLBACK TRANSACTION
      set @par_result = 'Database Error!';
    END
return @_transaction_error
    
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_raw_Do_Add_Input]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Do_Add_Input]
 @par_sessionID varchar(50),
 @par_ID bigint,
 @par_field_0 varchar(255),
 @par_field_1 varchar(255),
 @par_field_2 varchar(255),
 @par_field_3 varchar(255),
 @par_field_4 varchar(255),
 @par_field_5 varchar(255),
 @par_field_6 varchar(255),
 @par_field_7 varchar(255),
 @par_field_8 varchar(255),
 @par_field_9 varchar(255),
 @par_result varchar(150) output
AS --
BEGIN
declare @_transaction_error int;  


-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION


	insert into [raw_FileInput]
	(
	  [ID]
	 ,[Field_0]
	 ,[Field_1]
	 ,[Field_2]
	 ,[Field_3]
	 ,[Field_4]
	 ,[Field_5]
	 ,[Field_6]
	 ,[Field_7]
	 ,[Field_8]
	 ,[Field_9]
	)
	values
	(
	  @par_ID
	 ,@par_field_0
	 ,@par_field_1
	 ,@par_field_2
	 ,@par_field_3
	 ,@par_field_4
	 ,@par_field_5
	 ,@par_field_6
	 ,@par_field_7
	 ,@par_field_8
	 ,@par_field_9
	)

    --check status trasaction  
    select @_transaction_error = @@error
    if @_transaction_error <> 0 goto TRANSACTION_ERROR

    	   
COMMIT TRANSACTION
return 0
	   
TRANSACTION_ERROR:
IF @@TRANCOUNT > 0 
    BEGIN
      ROLLBACK TRANSACTION
      set @par_result = 'Database Error!';
    END
return @_transaction_error
    
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_def_Select_Output_Header]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_def_Select_Output_Header]
 @par_sessionID varchar(50)
AS --
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    select 
           [ID]
          ,[Field_Name]
    from def_FileOutputFormat_Fields
    order by [Field_No]
			
END
GO
/****** Object:  Table [dbo].[def_FileInputFormat_Fields]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[def_FileInputFormat_Fields](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID_def_FileInputFormat] [bigint] NOT NULL,
	[Field_No] [int] NOT NULL,
	[Field_Name] [varchar](50) NOT NULL,
	[Field_Type] [varchar](50) NOT NULL,
	[Field_Length] [int] NOT NULL,
	[Field_isMandatory] [bit] NOT NULL,
	[Field_Format] [varchar](50) NULL,
	[Field_OutputReplacementFormat] [varchar](50) NULL,
 CONSTRAINT [PK_def_FileInputFormat_Fields] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[def_FileInputFormat_Fields] ON
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (1, 1, 0, N'Identifier', N'varchar', 100, 1, NULL, N'Special:VBAR_DIV_NOtoACCCODE')
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (2, 1, 1, N'Name', N'varchar', 100, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (3, 1, 2, N'Type', N'varchar', 1, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (4, 1, 3, N'Opened', N'date', 10, 0, N'MM-dd-yyyy', N'yyyy-MM-dd')
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (5, 1, 4, N'Currency', N'varchar', 2, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (6, 2, 0, N'Name', N'varchar', 100, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (7, 2, 1, N'Type', N'varchar', 10, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (8, 2, 2, N'Currency', N'varchar', 1, 1, NULL, NULL)
INSERT [dbo].[def_FileInputFormat_Fields] ([ID], [ID_def_FileInputFormat], [Field_No], [Field_Name], [Field_Type], [Field_Length], [Field_isMandatory], [Field_Format], [Field_OutputReplacementFormat]) VALUES (10, 2, 3, N'Custodian Code', N'varchar', 100, 1, NULL, NULL)
SET IDENTITY_INSERT [dbo].[def_FileInputFormat_Fields] OFF
/****** Object:  Table [dbo].[def_Mapping_FileInput_FileOutput]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[def_Mapping_FileInput_FileOutput](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID_def_FileInputFormat_Fields] [bigint] NULL,
	[ID_def_FileOutputFormat_Fields] [bigint] NOT NULL,
 CONSTRAINT [PK_def_Mapping_FileInput_FileOutput] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[def_Mapping_FileInput_FileOutput] ON
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (1, 1, 1)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (2, 2, 2)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (3, 3, 3)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (4, 4, 4)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (5, 5, 5)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (6, 10, 1)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (7, 6, 2)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (8, 7, 3)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (9, NULL, 4)
INSERT [dbo].[def_Mapping_FileInput_FileOutput] ([ID], [ID_def_FileInputFormat_Fields], [ID_def_FileOutputFormat_Fields]) VALUES (10, 8, 5)
SET IDENTITY_INSERT [dbo].[def_Mapping_FileInput_FileOutput] OFF
/****** Object:  Table [dbo].[def_FileInputFormat_Fields_AcceptedValues]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[def_FileInputFormat_Fields_AcceptedValues](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[ID_def_FileInputFormat_Fields] [bigint] NOT NULL,
	[Value] [varchar](100) NOT NULL,
	[OutputReplacementValue] [varchar](100) NULL,
 CONSTRAINT [PK_def_FileInputFormat_Fields_AcceptedValues] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
SET IDENTITY_INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ON
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (1, 3, N'1', N'Trading')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (2, 3, N'2', N'RRSP')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (3, 3, N'3', N'RESP')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (4, 3, N'4', N'Fund')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (5, 5, N'CD', N'CAD')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (6, 5, N'US', N'USD')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (7, 8, N'C', N'CAD')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (9, 8, N'U', N'USD')
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (10, 7, N'Trading', NULL)
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (11, 7, N'RRSP', NULL)
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (12, 7, N'RESP', NULL)
INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] ([ID], [ID_def_FileInputFormat_Fields], [Value], [OutputReplacementValue]) VALUES (13, 7, N'Fund', NULL)
SET IDENTITY_INSERT [dbo].[def_FileInputFormat_Fields_AcceptedValues] OFF
/****** Object:  StoredProcedure [dbo].[up_def_Select_FileInputFormats_Fields]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_def_Select_FileInputFormats_Fields]
 @par_sessionID varchar(50),
 @par_ID bigint
AS --
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    --table 0
    select 
		   [ID]
		  ,[ID_def_FileInputFormat]
		  ,[Field_No]
		  ,[Field_Name]
		  ,[Field_Type]
		  ,[Field_Length]
		  ,[Field_isMandatory]
		  ,[Field_Format]
		  ,[Field_OutputReplacementFormat]
    from def_FileInputFormat_Fields
    where [ID_def_FileInputFormat] = @par_ID
    order by [Field_No]
    

    --table 1
    select 
           [ID]
          ,[Format]
          ,[hasHeader]
    from def_FileInputFormat
    where [ID] = @par_ID
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_raw_Do_MappingOuput]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_raw_Do_MappingOuput]
 @par_sessionID varchar(50),
 @par_ID bigint,
 @par_result varchar(150) output
AS --
BEGIN
declare @_transaction_error int;  
declare @Dynamic_SQLString NVARCHAR(4000);
declare @Dynamic_SQLString_Sub_1 NVARCHAR(4000);
declare @Dynamic_SQLString_Sub_2 NVARCHAR(4000);
declare @_temp_ID bigint;
declare @_temp_Field_No_IN int;
declare @_temp_Field_No_OUT int;

set @par_result = '';
set @Dynamic_SQLString_Sub_1 = '';
set @Dynamic_SQLString_Sub_2 = '';

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

BEGIN TRANSACTION

	declare cur_MappingOuput INSENSITIVE  cursor for 
		select 
		   [M].[ID]
		  ,[IN].[Field_No] as [Field_No_IN]
		  ,[OUT].[Field_No] as [Field_No_OUT]
		from [def_Mapping_FileInput_FileOutput] [M]
		   inner join def_FileInputFormat_Fields [IN] on [M].[ID_def_FileInputFormat_Fields] = [IN].[ID]
		   inner join def_FileOutputFormat_Fields [OUT] on [M].[ID_def_FileOutputFormat_Fields] = [OUT].[ID]  
		where [IN].[ID_def_FileInputFormat] = @par_ID
		order by [IN].[Field_No]
	FOR READ ONLY

	open cur_MappingOuput;
      
	fetch next from cur_MappingOuput
		 into  @_temp_ID
			  ,@_temp_Field_No_IN
			  ,@_temp_Field_No_OUT
    
	while (@@Fetch_Status = 0)
	  begin

			--generate the sql statement
			if (isnull(@_temp_Field_No_IN,-1) = -1)
			begin
			   set @Dynamic_SQLString_Sub_1 = @Dynamic_SQLString_Sub_1 + '[Field_NULL],';			
			end
			else
			begin
			   set @Dynamic_SQLString_Sub_1 = @Dynamic_SQLString_Sub_1 + '[Field_'+CONVERT(varchar(10),@_temp_Field_No_IN)+'],';
			end

		    set @Dynamic_SQLString_Sub_2 = @Dynamic_SQLString_Sub_2 + '[Field_'+CONVERT(varchar(10),@_temp_Field_No_OUT)+'],';			
	  
			--next iteration
			fetch next from cur_MappingOuput
				 into  @_temp_ID
					  ,@_temp_Field_No_IN
					  ,@_temp_Field_No_OUT
	  end
    
    --eliminate the last comma
    set @Dynamic_SQLString_Sub_1 = SUBSTRING(@Dynamic_SQLString_Sub_1,0,LEN(@Dynamic_SQLString_Sub_1));
    set @Dynamic_SQLString_Sub_2 = SUBSTRING(@Dynamic_SQLString_Sub_2,0,LEN(@Dynamic_SQLString_Sub_2));
    
    --compose the final output
    set @Dynamic_SQLString = 'insert into raw_FileOutput ([ID],' + @Dynamic_SQLString_Sub_2 +') select [ID],'+@Dynamic_SQLString_Sub_1+ ' from raw_FileInput order by [ID];';

    --execute the dynamic SQL
    EXEC sp_executesql @Dynamic_SQLString;
    
	--check status trasaction  
	select @_transaction_error = @@error
	if @_transaction_error <> 0 goto TRANSACTION_ERROR
    
    close cur_MappingOuput;
    deallocate cur_MappingOuput;


    	   
COMMIT TRANSACTION
return 0
	   
TRANSACTION_ERROR:
IF @@TRANCOUNT > 0 
    BEGIN
      ROLLBACK TRANSACTION
      set @par_result = 'Database Error!';
    END
return @_transaction_error
    
			
END
GO
/****** Object:  StoredProcedure [dbo].[up_def_Select_FileInputFormats_Fields_AcceptedValues]    Script Date: 05/25/2019 12:18:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[up_def_Select_FileInputFormats_Fields_AcceptedValues]
 @par_sessionID varchar(50),
 @par_ID bigint
AS --
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;  SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

    --table 0
    select 
	   [ID]
      ,[ID_def_FileInputFormat_Fields]
      ,[Value]
      ,[OutputReplacementValue]
    from def_FileInputFormat_Fields_AcceptedValues
    where [ID_def_FileInputFormat_Fields] = @par_ID
    order by [ID]
    
			
END
GO
/****** Object:  ForeignKey [FK_def_FileInputFormat_Fields_def_FileInputFormat]    Script Date: 05/25/2019 12:18:59 ******/
ALTER TABLE [dbo].[def_FileInputFormat_Fields]  WITH CHECK ADD  CONSTRAINT [FK_def_FileInputFormat_Fields_def_FileInputFormat] FOREIGN KEY([ID_def_FileInputFormat])
REFERENCES [dbo].[def_FileInputFormat] ([ID])
GO
ALTER TABLE [dbo].[def_FileInputFormat_Fields] CHECK CONSTRAINT [FK_def_FileInputFormat_Fields_def_FileInputFormat]
GO
/****** Object:  ForeignKey [FK_def_Mapping_FileInput_FileOutput_def_FileInput]    Script Date: 05/25/2019 12:18:59 ******/
ALTER TABLE [dbo].[def_Mapping_FileInput_FileOutput]  WITH CHECK ADD  CONSTRAINT [FK_def_Mapping_FileInput_FileOutput_def_FileInput] FOREIGN KEY([ID_def_FileInputFormat_Fields])
REFERENCES [dbo].[def_FileInputFormat_Fields] ([ID])
GO
ALTER TABLE [dbo].[def_Mapping_FileInput_FileOutput] CHECK CONSTRAINT [FK_def_Mapping_FileInput_FileOutput_def_FileInput]
GO
/****** Object:  ForeignKey [FK_def_Mapping_FileInput_FileOutput_def_FileOutput]    Script Date: 05/25/2019 12:18:59 ******/
ALTER TABLE [dbo].[def_Mapping_FileInput_FileOutput]  WITH CHECK ADD  CONSTRAINT [FK_def_Mapping_FileInput_FileOutput_def_FileOutput] FOREIGN KEY([ID_def_FileOutputFormat_Fields])
REFERENCES [dbo].[def_FileOutputFormat_Fields] ([ID])
GO
ALTER TABLE [dbo].[def_Mapping_FileInput_FileOutput] CHECK CONSTRAINT [FK_def_Mapping_FileInput_FileOutput_def_FileOutput]
GO
/****** Object:  ForeignKey [FK_def_FileInputFormat_Fields_AcceptedValues_def_FileInputFormat_Fields]    Script Date: 05/25/2019 12:18:59 ******/
ALTER TABLE [dbo].[def_FileInputFormat_Fields_AcceptedValues]  WITH CHECK ADD  CONSTRAINT [FK_def_FileInputFormat_Fields_AcceptedValues_def_FileInputFormat_Fields] FOREIGN KEY([ID_def_FileInputFormat_Fields])
REFERENCES [dbo].[def_FileInputFormat_Fields] ([ID])
GO
ALTER TABLE [dbo].[def_FileInputFormat_Fields_AcceptedValues] CHECK CONSTRAINT [FK_def_FileInputFormat_Fields_AcceptedValues_def_FileInputFormat_Fields]
GO
