﻿namespace Transform
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExitApplication = new System.Windows.Forms.Button();
            this.panelExit = new System.Windows.Forms.Panel();
            this.panelInput = new System.Windows.Forms.Panel();
            this.buttonGenerateOutputFile = new System.Windows.Forms.Button();
            this.buttonSelectInputFile = new System.Windows.Forms.Button();
            this.textBoxInputFileName = new System.Windows.Forms.TextBox();
            this.labelInputFile = new System.Windows.Forms.Label();
            this.labelInputFormat = new System.Windows.Forms.Label();
            this.comboBoxInputFormat = new System.Windows.Forms.ComboBox();
            this.labelInput1 = new System.Windows.Forms.Label();
            this.openFileInputDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.textBoxOutputDetails = new System.Windows.Forms.TextBox();
            this.labelOutputDetails = new System.Windows.Forms.Label();
            this.panelExit.SuspendLayout();
            this.panelInput.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonExitApplication
            // 
            this.buttonExitApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExitApplication.Location = new System.Drawing.Point(428, 3);
            this.buttonExitApplication.Name = "buttonExitApplication";
            this.buttonExitApplication.Size = new System.Drawing.Size(177, 45);
            this.buttonExitApplication.TabIndex = 0;
            this.buttonExitApplication.Text = "Exit Application";
            this.buttonExitApplication.UseVisualStyleBackColor = true;
            this.buttonExitApplication.Click += new System.EventHandler(this.buttonExitApplication_Click);
            // 
            // panelExit
            // 
            this.panelExit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelExit.Controls.Add(this.buttonExitApplication);
            this.panelExit.Location = new System.Drawing.Point(1, 399);
            this.panelExit.Name = "panelExit";
            this.panelExit.Size = new System.Drawing.Size(633, 55);
            this.panelExit.TabIndex = 1;
            // 
            // panelInput
            // 
            this.panelInput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelInput.Controls.Add(this.buttonGenerateOutputFile);
            this.panelInput.Controls.Add(this.buttonSelectInputFile);
            this.panelInput.Controls.Add(this.textBoxInputFileName);
            this.panelInput.Controls.Add(this.labelInputFile);
            this.panelInput.Controls.Add(this.labelInputFormat);
            this.panelInput.Controls.Add(this.comboBoxInputFormat);
            this.panelInput.Location = new System.Drawing.Point(1, 31);
            this.panelInput.Name = "panelInput";
            this.panelInput.Size = new System.Drawing.Size(633, 192);
            this.panelInput.TabIndex = 2;
            // 
            // buttonGenerateOutputFile
            // 
            this.buttonGenerateOutputFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonGenerateOutputFile.Location = new System.Drawing.Point(177, 147);
            this.buttonGenerateOutputFile.Name = "buttonGenerateOutputFile";
            this.buttonGenerateOutputFile.Size = new System.Drawing.Size(278, 35);
            this.buttonGenerateOutputFile.TabIndex = 6;
            this.buttonGenerateOutputFile.Text = "Generate Output File";
            this.buttonGenerateOutputFile.UseVisualStyleBackColor = true;
            this.buttonGenerateOutputFile.Click += new System.EventHandler(this.buttonGenerateOutputFile_Click);
            // 
            // buttonSelectInputFile
            // 
            this.buttonSelectInputFile.Location = new System.Drawing.Point(472, 61);
            this.buttonSelectInputFile.Name = "buttonSelectInputFile";
            this.buttonSelectInputFile.Size = new System.Drawing.Size(133, 23);
            this.buttonSelectInputFile.TabIndex = 5;
            this.buttonSelectInputFile.Text = "Select Input File";
            this.buttonSelectInputFile.UseVisualStyleBackColor = true;
            this.buttonSelectInputFile.Click += new System.EventHandler(this.buttonSelectInputFile_Click);
            // 
            // textBoxInputFileName
            // 
            this.textBoxInputFileName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxInputFileName.Location = new System.Drawing.Point(160, 61);
            this.textBoxInputFileName.Multiline = true;
            this.textBoxInputFileName.Name = "textBoxInputFileName";
            this.textBoxInputFileName.ReadOnly = true;
            this.textBoxInputFileName.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxInputFileName.Size = new System.Drawing.Size(295, 80);
            this.textBoxInputFileName.TabIndex = 4;
            // 
            // labelInputFile
            // 
            this.labelInputFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInputFile.Location = new System.Drawing.Point(31, 61);
            this.labelInputFile.Name = "labelInputFile";
            this.labelInputFile.Size = new System.Drawing.Size(99, 17);
            this.labelInputFile.TabIndex = 3;
            this.labelInputFile.Text = "Input File";
            // 
            // labelInputFormat
            // 
            this.labelInputFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInputFormat.Location = new System.Drawing.Point(31, 19);
            this.labelInputFormat.Name = "labelInputFormat";
            this.labelInputFormat.Size = new System.Drawing.Size(99, 17);
            this.labelInputFormat.TabIndex = 2;
            this.labelInputFormat.Text = "Input Format";
            // 
            // comboBoxInputFormat
            // 
            this.comboBoxInputFormat.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxInputFormat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxInputFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxInputFormat.FormattingEnabled = true;
            this.comboBoxInputFormat.Location = new System.Drawing.Point(160, 18);
            this.comboBoxInputFormat.Name = "comboBoxInputFormat";
            this.comboBoxInputFormat.Size = new System.Drawing.Size(295, 23);
            this.comboBoxInputFormat.TabIndex = 1;
            // 
            // labelInput1
            // 
            this.labelInput1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInput1.Location = new System.Drawing.Point(1, 4);
            this.labelInput1.Name = "labelInput1";
            this.labelInput1.Size = new System.Drawing.Size(633, 29);
            this.labelInput1.TabIndex = 0;
            this.labelInput1.Text = "Input Details";
            this.labelInput1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // openFileInputDialog1
            // 
            this.openFileInputDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileInputDialog1_FileOk);
            // 
            // textBoxOutputDetails
            // 
            this.textBoxOutputDetails.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxOutputDetails.Location = new System.Drawing.Point(5, 262);
            this.textBoxOutputDetails.Multiline = true;
            this.textBoxOutputDetails.Name = "textBoxOutputDetails";
            this.textBoxOutputDetails.ReadOnly = true;
            this.textBoxOutputDetails.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxOutputDetails.Size = new System.Drawing.Size(629, 131);
            this.textBoxOutputDetails.TabIndex = 5;
            // 
            // labelOutputDetails
            // 
            this.labelOutputDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOutputDetails.Location = new System.Drawing.Point(2, 234);
            this.labelOutputDetails.Name = "labelOutputDetails";
            this.labelOutputDetails.Size = new System.Drawing.Size(633, 28);
            this.labelOutputDetails.TabIndex = 6;
            this.labelOutputDetails.Text = "Output Details";
            this.labelOutputDetails.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 463);
            this.Controls.Add(this.labelOutputDetails);
            this.Controls.Add(this.textBoxOutputDetails);
            this.Controls.Add(this.panelInput);
            this.Controls.Add(this.panelExit);
            this.Controls.Add(this.labelInput1);
            this.MaximizeBox = false;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transform";
            this.Load += new System.EventHandler(this.Main_Load);
            this.panelExit.ResumeLayout(false);
            this.panelInput.ResumeLayout(false);
            this.panelInput.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExitApplication;
        private System.Windows.Forms.Panel panelExit;
        private System.Windows.Forms.Panel panelInput;
        private System.Windows.Forms.Label labelInput1;
        private System.Windows.Forms.Label labelInputFormat;
        private System.Windows.Forms.ComboBox comboBoxInputFormat;
        private System.Windows.Forms.OpenFileDialog openFileInputDialog1;
        private System.Windows.Forms.TextBox textBoxInputFileName;
        private System.Windows.Forms.Label labelInputFile;
        private System.Windows.Forms.Button buttonSelectInputFile;
        private System.Windows.Forms.Button buttonGenerateOutputFile;
        private System.Windows.Forms.TextBox textBoxOutputDetails;
        private System.Windows.Forms.Label labelOutputDetails;
    }
}

