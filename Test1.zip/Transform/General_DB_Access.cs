﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data.SqlClient;

namespace Transform
{
    class General_DB_Access
    {
        //Do Mapping Ouput
        public string raw_Do_MappingOuput(string par_sessionID, Int64 par_ID)
        {
            string result_val;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scon.Open();
                scmd = new SqlCommand("up_raw_Do_MappingOuput", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;
                scmd.Parameters.Add(new SqlParameter("@par_ID", SqlDbType.BigInt)).Value = par_ID;
                scmd.Parameters.Add(new SqlParameter("@par_result", SqlDbType.VarChar, 150, ParameterDirection.Output,
                    false, 0, 0, "par_result", DataRowVersion.Default, null));
                scmd.UpdatedRowSource = UpdateRowSource.OutputParameters;


                try
                {
                    scmd.ExecuteNonQuery();
                    result_val = scmd.Parameters["@par_result"].Value.ToString();

                    scon.Close();

                    return result_val;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Delete all from RAW tables
        public string raw_Do_Clear_All_RAW(string par_sessionID)
        {
            string result_val;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scon.Open();
                scmd = new SqlCommand("up_raw_Do_Clear_All_RAW", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;
                scmd.Parameters.Add(new SqlParameter("@par_result", SqlDbType.VarChar, 150, ParameterDirection.Output,
                    false, 0, 0, "par_result", DataRowVersion.Default, null));
                scmd.UpdatedRowSource = UpdateRowSource.OutputParameters;


                try
                {
                    scmd.ExecuteNonQuery();
                    result_val = scmd.Parameters["@par_result"].Value.ToString();

                    scon.Close();

                    return result_val;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Add to Input
        public string raw_Do_Add_Input(string par_sessionID,
            Int64 par_ID,
            string par_field_0,
            string par_field_1,
            string par_field_2,
            string par_field_3,
            string par_field_4,
            string par_field_5,
            string par_field_6,
            string par_field_7,
            string par_field_8,
            string par_field_9
            )
        {
            string result_val;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scon.Open();
                scmd = new SqlCommand("up_raw_Do_Add_Input", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                scmd.Parameters.Add(new SqlParameter("@par_ID", SqlDbType.BigInt)).Value = par_ID;
                scmd.Parameters.Add(new SqlParameter("@par_field_0", SqlDbType.VarChar, 255)).Value = par_field_0;
                scmd.Parameters.Add(new SqlParameter("@par_field_1", SqlDbType.VarChar, 255)).Value = par_field_1;
                scmd.Parameters.Add(new SqlParameter("@par_field_2", SqlDbType.VarChar, 255)).Value = par_field_2;
                scmd.Parameters.Add(new SqlParameter("@par_field_3", SqlDbType.VarChar, 255)).Value = par_field_3;
                scmd.Parameters.Add(new SqlParameter("@par_field_4", SqlDbType.VarChar, 255)).Value = par_field_4;
                scmd.Parameters.Add(new SqlParameter("@par_field_5", SqlDbType.VarChar, 255)).Value = par_field_5;
                scmd.Parameters.Add(new SqlParameter("@par_field_6", SqlDbType.VarChar, 255)).Value = par_field_6;
                scmd.Parameters.Add(new SqlParameter("@par_field_7", SqlDbType.VarChar, 255)).Value = par_field_7;
                scmd.Parameters.Add(new SqlParameter("@par_field_8", SqlDbType.VarChar, 255)).Value = par_field_8;
                scmd.Parameters.Add(new SqlParameter("@par_field_9", SqlDbType.VarChar, 255)).Value = par_field_9;

                scmd.Parameters.Add(new SqlParameter("@par_result", SqlDbType.VarChar, 150, ParameterDirection.Output,
                    false, 0, 0, "par_result", DataRowVersion.Default, null));
                scmd.UpdatedRowSource = UpdateRowSource.OutputParameters;


                try
                {
                    scmd.ExecuteNonQuery();
                    result_val = scmd.Parameters["@par_result"].Value.ToString();

                    scon.Close();

                    return result_val;

                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Add to Rejects
        public string raw_Do_Add_Reject(string par_sessionID, string par_notes)
        {
            string result_val;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scon.Open();
                scmd = new SqlCommand("up_raw_Do_Add_Reject", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                //trim the notes if longer
                if (par_notes.Length > 255) { par_notes = par_notes.Substring(0, 255); }
                scmd.Parameters.Add(new SqlParameter("@par_notes", SqlDbType.VarChar, 255)).Value = par_notes;

                scmd.Parameters.Add(new SqlParameter("@par_result", SqlDbType.VarChar, 150, ParameterDirection.Output,
                    false, 0, 0, "par_result", DataRowVersion.Default, null));
                scmd.UpdatedRowSource = UpdateRowSource.OutputParameters;


                try
                {
                    scmd.ExecuteNonQuery();
                    result_val = scmd.Parameters["@par_result"].Value.ToString();

                    scon.Close();

                    return result_val;

                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select Rejects
        public DataSet raw_Select_Rejects(string par_sessionID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_raw_Select_Rejects", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select Output_Header
        public DataSet def_Select_Output_Header(string par_sessionID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_def_Select_Output_Header", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select Output_Data
        public DataSet raw_Select_Output_Data(string par_sessionID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_raw_Select_Output_Data", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select File Input Formats
        public DataSet def_Select_FileInputFormats(string par_sessionID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_def_Select_FileInputFormats", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select File Input Format Fields
        public DataSet def_Select_FileInputFormats_Fields(string par_sessionID, Int64 par_ID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_def_Select_FileInputFormats_Fields", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;
                scmd.Parameters.Add(new SqlParameter("@par_ID", SqlDbType.BigInt)).Value = par_ID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

        //Select File Input Format Fields_AcceptedValues
        public DataSet def_Select_FileInputFormats_Fields_AcceptedValues(string par_sessionID, Int64 par_ID)
        {
            DataSet result;

            Transform Settings_Access = new Transform();
            String connect_str_DB = Settings_Access.CDB;

            SqlConnection scon = null;
            SqlCommand scmd = null;

            SqlDataAdapter sda = null;
            DataSet dsReturn = null;

            try
            {
                scon = new SqlConnection(connect_str_DB);
                scmd = new SqlCommand("up_def_Select_FileInputFormats_Fields_AcceptedValues", scon);
                scmd.CommandType = CommandType.StoredProcedure;
                scmd.CommandTimeout = 0;
                scmd.Parameters.Add(new SqlParameter("@par_sessionID", SqlDbType.VarChar, 50)).Value = par_sessionID;
                scmd.Parameters.Add(new SqlParameter("@par_ID", SqlDbType.BigInt)).Value = par_ID;

                try
                {
                    sda = new SqlDataAdapter(scmd);
                    dsReturn = new DataSet();
                    sda.Fill(dsReturn);
                    scon.Close();
                    result = dsReturn;

                    return dsReturn;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
            }

            finally
            {
                if (scon != null)
                {
                    if (scon.State != 0)
                        scon.Close();

                }
            }
        }

    }
}
