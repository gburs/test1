﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Transform
{
    public partial class Main : Form
    {

        public Main()
        {
            InitializeComponent();
        }

        private void buttonExitApplication_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }


        //-----------------------------------------------------
        // From DB gets the input formats 
        // and displays them into the DropDown ReadOnly
        //-----------------------------------------------------
        private void GetInputFromats()
        {
            General_DB_Access ins_General_DB_Access = new General_DB_Access();

            DataSet ds_DD_InputFormats = ins_General_DB_Access.def_Select_FileInputFormats("");

            comboBoxInputFormat.Items.Clear();

            //bind the combobox to a dictionary as the record ID in the table is needed - is the Key in the List
            Dictionary<string, string> comboSource = new Dictionary<string, string>();

            for (int i = 0; i < ds_DD_InputFormats.Tables[0].Rows.Count; i++)
            {
                comboSource.Add(ds_DD_InputFormats.Tables[0].Rows[i]["ID"].ToString(), ds_DD_InputFormats.Tables[0].Rows[i]["Format"].ToString());
            }

            comboBoxInputFormat.DataSource = new BindingSource(comboSource, null);
            comboBoxInputFormat.DisplayMember = "Value";
            comboBoxInputFormat.ValueMember = "Key";

            //for retrieval use
            //string key = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Key;
            //string value = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Value;

        }


        private void Main_Load(object sender, EventArgs e)
        {
            //load the input formats into the DropDown
            GetInputFromats();

        }

        private void buttonSelectInputFile_Click(object sender, EventArgs e)
        {
            openFileInputDialog1.FileName = "";
            openFileInputDialog1.ShowDialog();
        }

        private void openFileInputDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (openFileInputDialog1.FileName != "")
            {
                textBoxInputFileName.Text = openFileInputDialog1.FileName;
            }

        }

        private void buttonGenerateOutputFile_Click(object sender, EventArgs e)
        {
            //show a dialog box with Ok/Cancel buttons
            MessageBoxButtons db_buttons = MessageBoxButtons.OKCancel;
            DialogResult db_result;

            //display the dialog box and go on if fine
            db_result = MessageBox.Show("Confirm proceeding with file output generation?", "Confirmation", db_buttons);

            //proceed on confirmation only
            if (db_result == System.Windows.Forms.DialogResult.OK)
            {
                bool bProceed = true;

                //clear the output result display
                textBoxOutputDetails.Text = "";

                //check file format existance
                if (bProceed)
                {
                    if (comboBoxInputFormat.SelectedIndex == -1)
                    {
                        db_buttons = MessageBoxButtons.OK;
                        MessageBox.Show("Sorry... No Input Format Selected? \n(Select a format from the DropDown)", "Error", db_buttons);
                        bProceed = false;
                    }

                }

                //check file name existance
                if (bProceed)
                {
                    if (textBoxInputFileName.Text == "")
                    {
                        db_buttons = MessageBoxButtons.OK;
                        MessageBox.Show("Sorry... No Input File Selected? \n(Press Select Input File)", "Error", db_buttons);
                        bProceed = false;
                    }
                }

                //Step 1 Import File into the Raw Table
                if (bProceed)
                {
                    //set cursor to hourglass
                    Cursor.Current = Cursors.WaitCursor;
                    Application.UseWaitCursor = true;

                    //get the file format ID for validating the format definition
                    string sFileFormatID = ((KeyValuePair<string, string>)comboBoxInputFormat.SelectedItem).Key;                     
                    
                    General_DB_Access ins_General_DB_Access = new General_DB_Access();

                    //get the input format fields for upload validation
                    DataSet ds_DD_InputFormats_Fields = ins_General_DB_Access.def_Select_FileInputFormats_Fields("", Convert.ToInt64(sFileFormatID));

                    //clear raw tables
                    ins_General_DB_Access.raw_Do_Clear_All_RAW("");


                    //read the file line by line and process it
                    try
                    {
                        Int64 iCountLong = 1;

                        using (StreamReader sr = new StreamReader(textBoxInputFileName.Text))
                        {
                            //each line is comma split to obtain the fields 
                            while (!sr.EndOfStream)
                            {

                                //zero based in Field_No in the def_FileInputFormat_Fields table for allignement
                                string[] sFields = sr.ReadLine().Split(',');

                                //field values, now 10 and is the maximum number of fields from all imports
                                //fields are 0 based to match the mapping in the table: def_Mapping_FileInput_FileOutput 
                                string sField_0 = "";
                                string sField_1 = "";
                                string sField_2 = "";
                                string sField_3 = "";
                                string sField_4 = "";
                                string sField_5 = "";
                                string sField_6 = "";
                                string sField_7 = "";
                                string sField_8 = "";
                                string sField_9 = "";


                                //skip the header if encountered
                                if (!(
                                            (iCountLong == 1)
                                            &&
                                            (ds_DD_InputFormats_Fields.Tables[1].Rows[0]["hasHeader"].ToString().ToUpper() == "TRUE")
                                        )
                                   )
                                {

                                    //validate each field against the definition, if error display it
                                    for (int i = 0; i < sFields.Length; i++)
                                    {
                                        switch (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Type"].ToString())
                                        {
                                            case "varchar":
                                                {
                                                    //special parsing allways at the top
                                                    //check special cases and each has to be implemented separately
                                                    if (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_OutputReplacementFormat"].ToString() != "")
                                                    {
                                                        switch (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_OutputReplacementFormat"].ToString())
                                                        {
                                                            case "Special:VBAR_DIV_NOtoACCCODE":
                                                                string[] sSpecial = sFields[i].Split('|');

                                                                //check if condition is met
                                                                if (sSpecial.Length == 2)
                                                                {
                                                                    sFields[i] = sSpecial[1];
                                                                }
                                                                else //there is an error, special character not found
                                                                {
                                                                    ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " does not have the special vertical bar character: |.");
                                                                }

                                                                break;

                                                        }
                                                    }

                                                    //check length
                                                    if (sFields[i].Length > Convert.ToInt32(ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Length"].ToString()))
                                                    {
                                                        ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " has the length in excess of the definition. ");
                                                    }

                                                    //check mandatory (takes care of the special case too)
                                                    if (
                                                          (sFields[i].Trim().Length == 0)
                                                          &&
                                                          (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_isMandatory"].ToString().ToUpper() == "TRUE")
                                                       )
                                                    {
                                                        if (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_OutputReplacementFormat"].ToString() == "")
                                                        {//no special transformation case
                                                            ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " is mandatory. ");
                                                        }
                                                        else
                                                        {//add the special description (!!! make sure it is meaningful to the user)
                                                            ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " is mandatory - " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_OutputReplacementFormat"].ToString());
                                                        }

                                                    }

                                                    //check if in accepted range
                                                    DataSet ds_DD_InputFormats_Fields_AcceptedValues = ins_General_DB_Access.def_Select_FileInputFormats_Fields_AcceptedValues("", Convert.ToInt64(ds_DD_InputFormats_Fields.Tables[0].Rows[i]["ID"].ToString()));
                                                    if (ds_DD_InputFormats_Fields_AcceptedValues.Tables[0].Rows.Count > 0)
                                                    {
                                                        bool bFieldValueConstraint = false;
                                                        for (int i_1 = 0; i_1 < ds_DD_InputFormats_Fields_AcceptedValues.Tables[0].Rows.Count; i_1++)
                                                        {
                                                            if (sFields[i] == ds_DD_InputFormats_Fields_AcceptedValues.Tables[0].Rows[i_1]["Value"].ToString())
                                                            {
                                                                //check for replacement value
                                                                if (ds_DD_InputFormats_Fields_AcceptedValues.Tables[0].Rows[i_1]["OutputReplacementValue"].ToString() != "")
                                                                {
                                                                    sFields[i] = ds_DD_InputFormats_Fields_AcceptedValues.Tables[0].Rows[i_1]["OutputReplacementValue"].ToString();
                                                                }

                                                                //mark it found to avoid generating error messages
                                                                bFieldValueConstraint = true;

                                                                //no point in going further
                                                                break; 
                                                            }
                                                        }

                                                        //add to reject if not found
                                                        if (!bFieldValueConstraint)
                                                        {
                                                            ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " value is not found in the accepted values list.");
                                                        }


                                                    }

                                                    break;
                                                }
                                            case "date":
                                                {
                                                    //check mandatory
                                                    if (
                                                          (sFields[i].Trim().Length == 0)
                                                          &&
                                                          (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_isMandatory"].ToString().ToUpper() == "TRUE")
                                                       )
                                                    {
                                                        ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " is mandatory. ");
                                                    }

                                                    //check format
                                                    if (
                                                          (sFields[i].Length > 0)
                                                          &&
                                                          (ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Format"].ToString().Length > 0)
                                                       )
                                                    {
                                                        try
                                                        {
                                                            DateTime dTempDateTime = DateTime.ParseExact(sFields[i], ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Format"].ToString(),null);
                                                            
                                                            //if all good replace the field with the output conersion format
                                                            sFields[i] = dTempDateTime.ToString(ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_OutputReplacementFormat"].ToString());

                                                        }
                                                        catch
                                                        {
                                                            ins_General_DB_Access.raw_Do_Add_Reject("", "Row#: " + iCountLong.ToString() + " - Column#: " + (i + 1).ToString() + " - Column: " + ds_DD_InputFormats_Fields.Tables[0].Rows[i]["Field_Name"].ToString() + " has a date format issue. ");
                                                        }
                                                    }

                                                    break;
                                                }
                                        }

                                        
                                        //translate the table into fields
                                        //!!! Attention to mapping, it is one-to-one
                                        switch (i)
                                        {
                                            case 0: sField_0 = sFields[i]; break;
                                            case 1: sField_1 = sFields[i]; break;
                                            case 2: sField_2 = sFields[i]; break;
                                            case 3: sField_3 = sFields[i]; break;
                                            case 4: sField_4 = sFields[i]; break;
                                            case 5: sField_5 = sFields[i]; break;
                                            case 6: sField_6 = sFields[i]; break;
                                            case 7: sField_7 = sFields[i]; break;
                                            case 8: sField_8 = sFields[i]; break;
                                            case 9: sField_9 = sFields[i]; break;
                                        }

                                    }

                                    //here the line should have all the fields fine including their replacement value
                                    //write it to the raw_FileInput
                                    ins_General_DB_Access.raw_Do_Add_Input("",iCountLong,
                                        sField_0,
                                        sField_1,
                                        sField_2,
                                        sField_3,
                                        sField_4,
                                        sField_5,
                                        sField_6,
                                        sField_7,
                                        sField_8,
                                        sField_9);
                                }

                                iCountLong++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        textBoxOutputDetails.AppendText("Sorry... This file could not be processed - does not exist or could not be read!");
                        textBoxOutputDetails.AppendText(Environment.NewLine);
                        if (ex.Message != "")
                        {
                            textBoxOutputDetails.AppendText(ex.Message);
                            textBoxOutputDetails.AppendText(Environment.NewLine);
                        }

                        //file could not be found or read, system error, no point in going any further
                        bProceed = false;

                    }

                    //check pProceed flag
                    //Step 2: get rejects and output file
                    if (bProceed)
                    {
                        //download the rejects into a file
                        DataSet ds_Rejects = ins_General_DB_Access.raw_Select_Rejects("");

                        //check rejects
                        //if fine generate the output file (call a SQL SP to follow the mapping for output file) and write the final message to the user
                        //else notify the user where to find the rejects file
                        if (ds_Rejects.Tables[0].Rows.Count == 0)
                        {//no rejects
                            textBoxOutputDetails.AppendText("All fine - Rejected records not found!");
                            textBoxOutputDetails.AppendText(Environment.NewLine);

                            //do the mapping output
                            //if no error generate output file  
                            //have it in a try catch to get the mapping definition error
                            string sResultGenerateMapping = "";
                            bool bProceed_2 = false;
                            try
                            {
                                sResultGenerateMapping = ins_General_DB_Access.raw_Do_MappingOuput("", Convert.ToInt64(sFileFormatID));
                                bProceed_2 = true;
                            }
                            catch
                            {
                                textBoxOutputDetails.AppendText("Error in the mapping definition!");
                                textBoxOutputDetails.AppendText(Environment.NewLine);
                            }

                            //if fine, generate the ouput file
                            if (
                                (sResultGenerateMapping == "")
                                &&
                                (bProceed_2)
                               )
                            {
                                //have it wrapped within a [try catch] to capture any errors
                                try
                                {
                                    using (StreamWriter sw = new StreamWriter(textBoxInputFileName.Text + ".out"))
                                    {
                                        //first generarate the header
                                        DataSet ds_Output_Header = ins_General_DB_Access.def_Select_Output_Header("");
                                        string sTempLine_Out = "";
                                        for (int i = 0; i < ds_Output_Header.Tables[0].Rows.Count; i++)
                                        {
                                            sTempLine_Out = sTempLine_Out + ds_Output_Header.Tables[0].Rows[i]["Field_Name"].ToString() + ",";
                                        }
                                        sw.WriteLine(sTempLine_Out.Substring(0, sTempLine_Out.Length - 1));

                                        //first generarate the header
                                        DataSet ds_Output_Data = ins_General_DB_Access.raw_Select_Output_Data("");
                                        for (int i = 0; i < ds_Output_Data.Tables[0].Rows.Count; i++)
                                        {
                                            //reset the line
                                            sTempLine_Out = "";
                                            //use only the necessary fields
                                            for (int i_1 = 0; i_1 < ds_Output_Header.Tables[0].Rows.Count; i_1++)
                                            {
                                                sTempLine_Out = sTempLine_Out + ds_Output_Data.Tables[0].Rows[i]["Field_" + i_1.ToString()].ToString() + ",";
                                            }
                                            sw.WriteLine(sTempLine_Out.Substring(0, sTempLine_Out.Length - 1));
                                        }

                                    }


                                    textBoxOutputDetails.AppendText("Output generated in file: " + textBoxInputFileName.Text + ".out");
                                    textBoxOutputDetails.AppendText(Environment.NewLine);
                                }
                                catch (Exception ex)
                                {
                                    textBoxOutputDetails.AppendText("Sorry... Output records could not be downloaded to a file!");
                                    textBoxOutputDetails.AppendText(Environment.NewLine);
                                }

                            }


                        }
                        else//rejects found
                        {

                            //have it wrapped within a [try catch] to capture any errors
                            try
                            {
                                using (StreamWriter sw = new StreamWriter(textBoxInputFileName.Text + ".err"))
                                {
                                    for (int i = 0; i < ds_Rejects.Tables[0].Rows.Count; i++)
                                    {
                                        sw.WriteLine(ds_Rejects.Tables[0].Rows[i]["Notes"].ToString());
                                    }
                                }

                                textBoxOutputDetails.AppendText("Rejects found, details in file: " + textBoxInputFileName.Text + ".err");
                                textBoxOutputDetails.AppendText(Environment.NewLine);

                            }
                            catch (Exception ex)
                            {
                                textBoxOutputDetails.AppendText("Sorry... Rejects found and could not be downloaded to a file!");
                                textBoxOutputDetails.AppendText(Environment.NewLine);
                            }

                        }
                    }

                    //reset the cursor back
                    Cursor.Current = Cursors.Default;
                    Application.UseWaitCursor = false;
                }

            }



        }
    }
}
